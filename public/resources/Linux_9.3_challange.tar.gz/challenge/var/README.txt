var variable data
