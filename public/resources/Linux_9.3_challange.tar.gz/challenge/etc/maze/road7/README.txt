What's the difference beween "ls" and "ls -a"?
