🐄 Wise Cow Challenge 🐄

Goal: Find the wise cow and get the flag!

Story:
A wise cow has gone on a trip in the digital world. She left behind clues
scattered throughout the filesystem. Follow her trail to find her hiding spot!

Start your adventure by exploring the home directory!.
Remember: the wise cow speaks in riddles and loves to hide things...

Good luck, seeker! 🌟
