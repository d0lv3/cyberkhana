root placeholder - nothing interesting here
